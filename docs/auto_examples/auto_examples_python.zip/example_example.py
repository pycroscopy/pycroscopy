
"""
An Example on writing examples
==============================

The example docstring will be printed as text along with the code of the example.
It should contain the desciption of the example code.
Only examples that begine with plot_* will be run when generating the docs.

"""

# Code source: Chris Smith
# Liscense: MIT
print('I am an example')
